3D VAULT KEYCHAIN — ADK Workshop
================================
Size: 78 x 24 mm, 4 mm thick (logo 4.6 mm). Hole for a split ring: 5.2 mm.

FILES
  3DVault-Keychain.3mf        Two parts (dark base + teal logo/text) — for AMS / multi-material printers.
                              Bambu Studio / OrcaSlicer: answer "Yes" to "load as a single object with multiple parts",
                              then give each part its own filament.
  3DVault-Keychain.stl        Single body — for one color, or two colors with a filament change (below).
  3DVault-Keychain-Base.stl   Base only (0 - 3 mm).
  3DVault-Keychain-Top.stl    Logo, text and rim only (3 - 4.6 mm).

PRINT SETTINGS
  PLA or PETG, 0.2 mm layers, 0.4 mm nozzle, 3 walls, 15-20 % infill, no supports, flat on the bed.
  About 25 minutes and 6 g.

TWO COLORS WITHOUT AMS
  Slice 3DVault-Keychain.stl and add a filament change (M600 / "Add color change") at 3.0 mm
  — the first layer above 3.0 mm (3.2 mm at 0.2 mm layers). Start with dark filament, switch to teal.

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it — please credit "ADK Workshop / 3D Vault".
  https://3dvault.adkworkshop.com

-------------------------------------------------------------------------------------------------

3D VAULT ANAHTARLIĞI — ADK Workshop
===================================
Ölçü: 78 x 24 mm, 4 mm kalınlık (logo 4,6 mm). Halka deliği: 5,2 mm.

DOSYALAR
  3DVault-Keychain.3mf        İki parça (koyu taban + turkuaz logo/yazı) — AMS / çok renkli yazıcılar için.
                              Bambu Studio / OrcaSlicer: "tek nesne, çok parça olarak yükle" sorusuna "Evet" de,
                              her parçaya kendi filamentini ver.
  3DVault-Keychain.stl        Tek gövde — tek renk ya da filament değiştirerek iki renk (aşağıda).
  3DVault-Keychain-Base.stl   Sadece taban (0 - 3 mm).
  3DVault-Keychain-Top.stl    Sadece logo, yazı ve kenar (3 - 4,6 mm).

BASKI AYARLARI
  PLA ya da PETG, 0,2 mm katman, 0,4 mm nozul, 3 duvar, %15-20 dolgu, destek yok, tablaya düz.
  Yaklaşık 25 dakika ve 6 g.

AMS OLMADAN İKİ RENK
  3DVault-Keychain.stl'yi dilimle, 3,0 mm'de filament değişimi ekle (M600 / "Renk değişimi ekle")
  — 3,0 mm'nin üstündeki ilk katman (0,2 mm katmanda 3,2 mm). Koyu filamentle başla, turkuaza geç.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir — lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
