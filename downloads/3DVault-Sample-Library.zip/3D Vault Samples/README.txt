3D VAULT SAMPLE LIBRARY — ADK Workshop
=====================================
A small set of original 3D models to try 3D Vault with when you have no files of your own at hand.

HOW TO USE
  1) Extract this ZIP to any folder, e.g. Documents\3D Vault Samples
  2) In 3D Vault: Settings -> Libraries -> Add, and choose that folder
     (or drop the folder onto the 3D Vault window when it is empty)
  3) Previews are generated in a few seconds. Then try:
     - Search, the folder tree, categories and tags on the left
     - Kits inside ZIP / 7z archives (Planetary Gear Kit, Lathe Chess Set): their parts and previews
     - "Knight Statue Kit": two scales (1/6 and 1/10) and a pre-supported version -> Scale and Options
     - "Spiral Vase - 0.2mm PLA.gcode": open it, 3D tab -> layer-by-layer toolpath view
     - Print tab: volume, cost and the Mesh check ("Open Cup - has a hole" fails on purpose)
     - "Wall Hook" is saved tilted: 3D tab -> orientation suggestions
  When you are done you can remove the library (your files are never deleted) and add your own folders.
  The free version allows one library — remove this one first.

LICENSE
  All models: Creative Commons Attribution 4.0 (CC BY 4.0) — ADK Workshop. Print, share and remix them.
  https://3dvault.adkworkshop.com

-------------------------------------------------------------------------------------------------

3D VAULT ÖRNEK KÜTÜPHANESİ — ADK Workshop
=========================================
Elinde kendi dosyan yokken 3D Vault'u denemek için küçük, özgün bir 3D model seti.

KULLANIM
  1) Bu ZIP'i bir klasöre aç, ör. Belgeler\3D Vault Örnekleri
  2) 3D Vault: Ayarlar -> Kütüphaneler -> Ekle, o klasörü seç
     (ya da program boşken klasörü pencereye sürükle)
  3) Önizlemeler birkaç saniyede hazırlanır. Sonra şunları dene:
     - Arama, soldaki klasör ağacı, kategoriler ve etiketler
     - ZIP / 7z arşivlerindeki kitler (Planetary Gear Kit, Lathe Chess Set): parçalar ve önizlemeler
     - "Knight Statue Kit": iki ölçek (1/6 ve 1/10) ve destekli sürüm -> Ölçek ve Seçenekler
     - "Spiral Vase - 0.2mm PLA.gcode": aç, 3D sekmesi -> katman katman takım yolu görünümü
     - Baskı sekmesi: hacim, maliyet ve Mesh kontrolü ("Open Cup - has a hole" bilerek sorunlu)
     - "Wall Hook" eğik kaydedildi: 3D sekmesi -> tablada duruş önerileri
  İşin bitince kütüphaneyi kaldırabilirsin (dosyaların asla silinmez) ve kendi klasörlerini eklersin.
  Ücretsiz sürümde tek kütüphane olur — önce bunu kaldır.

LİSANS
  Bütün modeller: Creative Commons Atıf 4.0 (CC BY 4.0) — ADK Workshop. Bas, paylaş, değiştir.
