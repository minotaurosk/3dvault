BATWING PUMPKIN BOWL — Pumpkin Patch Pals #5 · free Halloween candy bowl from 3D Vault (ADK Workshop)
=====================================================================================================
Size: 168 x 152 mm, 79 mm tall (leafy base). Watertight, single body, checked with 3D Vault's mesh check.
The bowl is open at the top for candy, small toys or a battery tealight (no real candles: PLA softens).
The bottom is cut flat for a solid first layer (about 12,680 mm² on the bed), with a small "3D Vault" stamp
engraved 1 mm deep under it: invisible on display.

THE SERIES
  Pumpkin Patch Pals: six cute Halloween prints in the same style, one a day until Halloween.
  #1 Pumpkin Witchling · #2 Candy Boo · #3 Pumpkin Purrfection · #4 Tiny Bat Prince · #5 Batwing Pumpkin Bowl
  · next: a ghost cottage.

HOW IT WAS MADE
  Picture made with AI (Gemini), turned into 3D with Meshy AI (paid plan), then made print-ready:
  this time Meshy's file was already closed (0 holes, 0 non-manifold edges), but it was 1 mm wide in a slicer
  (saved in meters). Scaled to 79 mm tall, bottom cut 1.4 mm flat, stamp engraved, checked again in 3D Vault.

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.16–0.2 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports only under the bat wings: tree / organic supports.
         Full size: about 16 hours and 170 g of PLA at 0.16 mm (PrusaSlicer).
         Smaller: at 70 % (118 mm wide) and 0.2 mm layers, about 7 hours and 75 g.
  Colors (paint or multi-color): orange pumpkin, dark purple wings, autumn leaves; see the preview.
  Food: PLA prints are not food safe; use it for wrapped candy only.

FILES
  Batwing Pumpkin Bowl - 79mm - 3D Vault.stl    full detail (0.8 M triangles)
  Batwing Pumpkin Bowl - preview.jpg            color render (Meshy AI texture)
  Batwing Pumpkin Bowl - bottom stamp.jpg       the flat base with the engraved stamp

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

BATWING PUMPKIN BOWL — Kabak Bahçesi Dostları #5 · 3D Vault'tan ücretsiz Cadılar Bayramı şeker kasesi (ADK Workshop)
================================================================================================================
Ölçü: 168 x 152 mm, boy 79 mm (yapraklı kaide). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Üstü açık: şeker, küçük oyuncak ya da pilli mum için (gerçek mum koymayın: PLA yumuşar).
Alt yüz sağlam bir ilk katman için düz kesildi (tablada ~12.680 mm²); altında 1 mm derin küçük "3D Vault" damgası var.

SERİ
  Kabak Bahçesi Dostları: aynı tarzda altı sevimli Cadılar Bayramı baskısı, bayrama kadar her gün bir tane.

NASIL YAPILDI
  AI (Gemini) ile yapılan resim, Meshy AI (ücretli plan) ile 3D'ye çevrildi, sonra baskıya hazırlandı:
  bu sefer Meshy dosyası zaten kapalıydı (0 delik), ama dilimleyicide 1 mm'ydi. 79 mm boya ölçeklendi,
  alt yüz 1,4 mm düz kesildi, damga kazındı, 3D Vault'ta yeniden kontrol edildi.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,16–0,2 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Sadece yarasa kanatlarının altına
          ağaç / organik destek. Tam boy: 0,16 mm'de yaklaşık 16 saat ve 170 g PLA (PrusaSlicer).
          %70 boyut (118 mm) ve 0,2 mm katmanla yaklaşık 7 saat ve 75 g.
  Gıda:   PLA baskılar gıdaya uygun değildir; sadece ambalajlı şeker koyun.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
