COZY GHOST COTTAGE — Pumpkin Patch Pals #6 · free Halloween figure from 3D Vault (ADK Workshop)
===============================================================================================
Size: 78 mm tall (76 x 73 mm, leafy base). Watertight, single body, checked with 3D Vault's mesh check.
The bottom is cut flat for a solid first layer (about 2,000 mm² on the bed), with a small "3D Vault" stamp
engraved 1 mm deep under it: invisible on display.

THE SERIES
  Pumpkin Patch Pals: six cute Halloween figures in the same style, all six out for Halloween.
  #1 Pumpkin Witchling · #2 Candy Boo · #3 Pumpkin Purrfection · #4 Tiny Bat Prince · #5 Batwing Pumpkin Bowl
  · #6 Cozy Ghost Cottage.

HOW IT WAS MADE
  Picture made with AI (Gemini), turned into 3D with Meshy AI (paid plan), then made print-ready:
  Meshy's file had 46 holes and 70 non-manifold edges and was 1 mm tall in a slicer (saved in meters).
  Scaled to 80 mm, voxel remeshed at 0.15 mm, bottom cut 1.6 mm flat,
  stamp engraved, checked again in 3D Vault.

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.12–0.16 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports needed under the roof edges, the chimney and the ghost: tree / organic supports.
         About 5 hours and 45 g of PLA at 0.16 mm (PrusaSlicer).
  Resin: hollow to 1.5–2 mm with drain holes, tilt 30–45°, light supports under the roof edges.
  Colors (paint or multi-color): purple roof, dark grey walls, yellow windows, white ghost, autumn leaves; see the preview.
  Scale freely: 100 mm and up gives the leaf tips more strength.

FILES
  Cozy Ghost Cottage - 78mm - 3D Vault.stl    full detail (2.4 M triangles)
  Cozy Ghost Cottage - preview.jpg            color render (Meshy AI texture)
  Cozy Ghost Cottage - bottom stamp.jpg       the flat base with the engraved stamp

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

COZY GHOST COTTAGE — Kabak Bahçesi Dostları #6 · 3D Vault'tan ücretsiz Cadılar Bayramı figürü (ADK Workshop)
======================================================================================================
Boy: 78 mm (76 x 73 mm, yapraklı kaide). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Alt yüz sağlam bir ilk katman için düz kesildi (tablada ~2.000 mm²); altında 1 mm derin küçük "3D Vault" damgası var.

SERİ
  Kabak Bahçesi Dostları: aynı tarzda altı sevimli Cadılar Bayramı figürü, altısı da yayında.

NASIL YAPILDI
  AI (Gemini) ile yapılan resim, Meshy AI (ücretli plan) ile 3D'ye çevrildi, sonra baskıya hazırlandı:
  Meshy dosyasında 46 delik ve 70 çok yüzlü kenar vardı, dilimleyicide 1 mm'ydi. 80 mm'ye ölçeklendi,
  0,15 mm voxel ile yeniden örüldü, alt yüz düz kesildi, damga kazındı, 3D Vault'ta yeniden kontrol edildi.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,12–0,16 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Çatı kenarları, baca ve hayaletin altına
          ağaç / organik destek. 0,16 mm'de yaklaşık 5 saat ve 45 g PLA (PrusaSlicer).
  Reçine: 1,5–2 mm içi boş, tahliye delikleri, 30–45° eğik, çatı kenarlarına hafif destek.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
