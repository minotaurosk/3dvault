TINY BAT PRINCE — Pumpkin Patch Pals #4 · free Halloween figure from 3D Vault (ADK Workshop)
===============================================================================================
Size: 79 mm tall (78 x 70 mm, leafy base). Watertight, single body, checked with 3D Vault's mesh check.
The bottom is cut flat for a solid first layer (about 3,140 mm² on the bed), with a small "3D Vault" stamp
engraved 1 mm deep under it: invisible on display.

THE SERIES
  Pumpkin Patch Pals: six cute Halloween figures in the same style, one every couple of days until Halloween.
  #1 Pumpkin Witchling · #2 Candy Boo · #3 Pumpkin Purrfection · #4 Tiny Bat Prince · next: a candy bowl and a ghost cottage.

HOW IT WAS MADE
  Picture made with AI (Gemini), turned into 3D with Meshy AI (paid plan), then made print-ready:
  Meshy's file had 51 holes and 83 non-manifold edges and was 1 mm tall in a slicer (saved in meters).
  Scaled to 80 mm, voxel remeshed at 0.15 mm, bottom cut 0.8 mm flat,
  stamp engraved, checked again in 3D Vault.

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.12–0.16 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports needed under the cape, the hands and the little bat: tree / organic supports.
         About 5 hours and 39 g of PLA at 0.16 mm (PrusaSlicer).
  Resin: hollow to 1.5–2 mm with drain holes, tilt 30–45°, light supports under the cape.
  Colors (paint or multi-color): black hair, purple cape, grey tombstone and bat, autumn leaves; see the preview.
  Scale freely: 100 mm and up gives the leaf tips more strength.

FILES
  Tiny Bat Prince - 79mm - 3D Vault.stl    full detail (2.4 M triangles)
  Tiny Bat Prince - preview.jpg            color render (Meshy AI texture)
  Tiny Bat Prince - bottom stamp.jpg       the flat base with the engraved stamp

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

TINY BAT PRINCE — Kabak Bahçesi Dostları #4 · 3D Vault'tan ücretsiz Cadılar Bayramı figürü (ADK Workshop)
======================================================================================================
Boy: 79 mm (78 x 70 mm, yapraklı kaide). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Alt yüz sağlam bir ilk katman için düz kesildi (tablada ~3.140 mm²); altında 1 mm derin küçük "3D Vault" damgası var.

SERİ
  Kabak Bahçesi Dostları: aynı tarzda altı sevimli Cadılar Bayramı figürü, bayrama kadar iki günde bir.

NASIL YAPILDI
  AI (Gemini) ile yapılan resim, Meshy AI (ücretli plan) ile 3D'ye çevrildi, sonra baskıya hazırlandı:
  Meshy dosyasında 51 delik ve 83 çok yüzlü kenar vardı, dilimleyicide 1 mm'ydi. 80 mm'ye ölçeklendi,
  0,15 mm voxel ile yeniden örüldü, alt yüz düz kesildi, damga kazındı, 3D Vault'ta yeniden kontrol edildi.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,12–0,16 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Pelerin, eller ve yarasanın altına
          ağaç / organik destek. 0,16 mm'de yaklaşık 5 saat ve 39 g PLA (PrusaSlicer).
  Reçine: 1,5–2 mm içi boş, tahliye delikleri, 30–45° eğik, pelerinin altına hafif destek.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
