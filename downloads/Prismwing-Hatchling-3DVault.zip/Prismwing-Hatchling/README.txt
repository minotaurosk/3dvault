PRISMWING HATCHLING — free 3D printable baby dragon from 3D Vault (ADK Workshop)
================================================================================
Size: 80 mm tall (67 x 62 mm, rock base 52 x 42 mm). Watertight, single body, checked with 3D Vault's mesh check.
The "3D Vault" stamp is engraved 1 mm deep under the rock: invisible on display, no supports needed there.

HOW IT WAS MADE
  2024: a 2D picture I made with AI. Background cleaned with Gemini, turned into 3D with Meshy AI (paid plan),
  then made print-ready: scaled from meters to 80 mm (Meshy's file was 1 mm tall in a slicer), 5 small holes
  closed with a 0.15 mm voxel remesh, stamp engraved. Wings are 1.2–2 mm thick at this size.
  Full story: instagram.com/adk_3dvault

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.12–0.16 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports needed under the wings and chin: tree / organic supports.
         About 3.5 hours and 24 g of PLA at 0.16 mm (PrusaSlicer).
  Resin: hollow to 1.5–2 mm with drain holes in the rock, tilt 30–45°, light supports on the wing tips.
  Scale: 100 mm and up gives sturdier wings; below 70 mm the wing edges get too thin for FDM.

FILES
  Prismwing Hatchling - 80mm - 3D Vault.stl   full detail (1.5 M triangles)
  Prismwing Hatchling - preview.jpg            color render (Meshy AI texture)
  Prismwing Hatchling - bottom stamp.jpg       the engraved rock base

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

PRISMWING HATCHLING — 3D Vault'tan ücretsiz basılabilir bebek ejderha (ADK Workshop)
==================================================================================
Boy: 80 mm (67 x 62 mm, kaya tabanı 52 x 42 mm). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Kayanın altında 1 mm derin "3D Vault" damgası var: dışarıdan görünmez, orada destek gerekmez.

NASIL YAPILDI
  2024'te AI ile yaptığım 2D bir resim. Arka planı Gemini ile temizlendi, Meshy AI (ücretli plan) ile 3D'ye
  çevrildi, sonra baskıya hazırlandı: metreden 80 mm'ye ölçeklendi (Meshy dosyası dilimleyicide 1 mm'ydi),
  5 küçük delik 0,15 mm voxel ile kapatıldı, damga kazındı. Bu boyda kanatlar 1,2–2 mm kalınlıkta.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,12–0,16 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Kanat ve çene altına ağaç / organik
          destek. 0,16 mm'de yaklaşık 3,5 saat ve 24 g PLA (PrusaSlicer).
  Reçine: 1,5–2 mm içi boş, kayaya tahliye deliği, 30–45° eğik, kanat uçlarına hafif destek.
  Ölçek: 100 mm ve üstünde kanatlar daha sağlam; 70 mm'nin altında kanat kenarları FDM için incelir.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
