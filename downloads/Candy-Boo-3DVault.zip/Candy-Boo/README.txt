CANDY BOO — Pumpkin Patch Pals #2 · free Halloween figure from 3D Vault (ADK Workshop)
===============================================================================================
Size: 80 mm tall (94 x 94 mm, leafy base). Watertight, single body, checked with 3D Vault's mesh check.
The bottom is cut flat for a solid first layer (about 3,850 mm² on the bed), with a small "3D Vault" stamp
engraved 1 mm deep under it: invisible on display.

THE SERIES
  Pumpkin Patch Pals: six cute Halloween figures in the same style, one every couple of days until Halloween.
  #1 Pumpkin Witchling · #2 Candy Boo · next: a pumpkin kitten, a tiny vampire, a candy bowl and a ghost cottage.

HOW IT WAS MADE
  Picture made with AI (Gemini), turned into 3D with Meshy AI (paid plan), then made print-ready:
  Meshy's file had 17 holes and 28 non-manifold edges and was 1 mm tall in a slicer (saved in meters).
  Scaled to 80 mm, voxel remeshed at 0.15 mm, simplified to 1.7 M triangles, bottom cut 0.4 mm flat, stamp engraved,
  checked again in 3D Vault.

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.12–0.16 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports needed under the arms and the candy bucket: tree / organic supports.
         Full size (80 mm) is chunky: about 8 hours and 78 g of PLA at 0.16 mm (PrusaSlicer).
         At 70 % (56 mm) it takes about 3 hours and 27 g.
  Resin: hollow to 1.5–2 mm with drain holes, tilt 30–45°, light supports under the arms.
  Colors (paint or multi-color): white ghost, orange candy bucket, autumn leaves; see the preview.
  Scale freely: below 60 % the leaf tips get thin for FDM.

FILES
  Candy Boo - 80mm - 3D Vault.stl    full detail (1.7 M triangles)
  Candy Boo - preview.jpg            color render (Meshy AI texture)
  Candy Boo - bottom stamp.jpg       the flat base with the engraved stamp

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

CANDY BOO — Kabak Bahçesi Dostları #2 · 3D Vault'tan ücretsiz Cadılar Bayramı figürü (ADK Workshop)
======================================================================================================
Boy: 80 mm (94 x 94 mm, yapraklı kaide). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Alt yüz sağlam bir ilk katman için düz kesildi (tablada ~3.850 mm²); altında 1 mm derin küçük "3D Vault" damgası var.

SERİ
  Kabak Bahçesi Dostları: aynı tarzda altı sevimli Cadılar Bayramı figürü, bayrama kadar iki günde bir.

NASIL YAPILDI
  AI (Gemini) ile yapılan resim, Meshy AI (ücretli plan) ile 3D'ye çevrildi, sonra baskıya hazırlandı:
  Meshy dosyasında 17 delik ve 28 çok yüzlü kenar vardı, dilimleyicide 1 mm'ydi. 80 mm'ye ölçeklendi,
  0,15 mm voxel ile yeniden örüldü, alt yüz düz kesildi, damga kazındı, 3D Vault'ta yeniden kontrol edildi.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,12–0,16 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Kolların ve şeker kovasının altına
          ağaç / organik destek. Tam boy (80 mm) yaklaşık 8 saat ve 78 g; %70 ölçekte yaklaşık 3 saat ve 27 g.
  Reçine: 1,5–2 mm içi boş, tahliye delikleri, 30–45° eğik, kolların altına hafif destek.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
