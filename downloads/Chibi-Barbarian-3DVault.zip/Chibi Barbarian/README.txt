CHIBI BARBARIAN — free 3D printable figure from 3D Vault (ADK Workshop)
========================================================================
Size: 80 mm tall (52 x 47 mm base). Watertight, single body, checked with 3D Vault's mesh check.
The "3D Vault" stamp is engraved 1 mm deep under the base: invisible on display, no supports needed.

HOW IT WAS MADE
  Generated with Meshy AI (paid plan), then made print-ready:
  scaled from meters to 80 mm, voxel remeshed at 0.15 mm (Meshy's mesh had 63 holes and 130 non-manifold
  edges), stray fragments removed, stamp engraved. Full story: instagram.com/adk_3dvault

PRINT SETTINGS (tested in the slicer, not yet on a printer)
  FDM:   0.12–0.16 mm layers, 0.4 mm nozzle, 3 walls, 15 % infill, PLA.
         Supports needed (arms, sword, hair): tree / organic supports, touching build plate is enough
         for the sword; everywhere for the hair and arms. About 4–5 hours at 0.16 mm.
  Resin: hollow to 1.5–2 mm, add drain holes in the base, tilt 30–45° with light supports.
  Scale freely: 120 mm and up looks great; below 60 mm the hair strands get thin for FDM.

FILES
  Chibi Barbarian - 80mm - 3D Vault.stl   full detail (1.67 M triangles)
  Chibi Barbarian - preview.jpg            render
  Chibi Barbarian - bottom stamp.jpg       the engraved base

LICENSE
  Creative Commons Attribution 4.0 (CC BY 4.0): print it, share it, remix it.
  Please credit "ADK Workshop / 3D Vault".

ABOUT 3D VAULT
  A free Windows app that turns your folders of STL / 3MF / G-code files (even inside ZIP and RAR) into a
  searchable library with previews, a G-code layer view and the mesh check used on this model.
  https://3dvault.adkworkshop.com  ·  Microsoft Store: https://apps.microsoft.com/detail/9PCZMDJ2531J

--------------------------------------------------------------------------------------------------------

CHIBI BARBAR — 3D Vault'tan ücretsiz basılabilir figür (ADK Workshop)
=====================================================================
Boy: 80 mm (kaide 52 x 47 mm). Su geçirmez, tek gövde; 3D Vault mesh kontrolünden geçti.
Kaidenin altında 1 mm derin "3D Vault" damgası var: dışarıdan görünmez, destek gerektirmez.

NASIL YAPILDI
  Meshy AI (ücretli plan) ile üretildi, sonra baskıya hazırlandı: metreden 80 mm'ye ölçeklendi, 0,15 mm voxel ile
  yeniden örüldü (Meshy'nin modelinde 63 delik ve 130 çok yüzlü kenar vardı), kopuk parçalar temizlendi, damga kazındı.

BASKI AYARLARI (dilimleyicide denendi, henüz yazıcıda basılmadı)
  FDM:    0,12–0,16 mm katman, 0,4 mm nozul, 3 duvar, %15 dolgu, PLA. Destek gerekli (kollar, kılıç, saç):
          ağaç / organik destek. 0,16 mm'de yaklaşık 4–5 saat.
  Reçine: 1,5–2 mm içi boş, kaideye tahliye deliği, 30–45° eğik, hafif destek.
  Ölçek serbest: 120 mm ve üstü çok iyi görünür; 60 mm'nin altında saç telleri FDM için incelir.

LİSANS
  Creative Commons Atıf 4.0 (CC BY 4.0): bas, paylaş, değiştir. Lütfen "ADK Workshop / 3D Vault" diye kaynak göster.
